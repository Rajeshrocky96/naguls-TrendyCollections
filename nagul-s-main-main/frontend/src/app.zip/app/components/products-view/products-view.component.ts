import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { SidebarComponent } from '../sidebar/sidebar.component';

@Component({
  selector: 'app-products-view',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule, ReactiveFormsModule, SidebarComponent],
  templateUrl: './products-view.component.html',
  styleUrls: ['./products-view.component.scss']
})
export class ProductsViewComponent {
  // Simple in-memory data model
  products: Product[] = [
    {
      id: 1,
      name: "Cotton T-Shirt",
      category: "Apparel",
      image: "",
      description: "Soft cotton tee.",
      status: 'Active',
      lastUpdated: new Date(),
      variants: [
        { size: 'M', color: 'Black', price: 599, stock: 24 },
        { size: 'L', color: 'White', price: 599, stock: 8 }
      ]
    },
    {
      id: 2,
      name: "Denim Jeans",
      category: "Apparel",
      image: "",
      description: "Slim fit denim.",
      status: 'Inactive',
      lastUpdated: new Date(),
      variants: [
        { size: '32', color: 'Blue', price: 1299, stock: 5 }
      ]
    },
    {
      id: 3,
      name: "Sports Shoes",
      category: "Footwear",
      image: "",
      description: "Lightweight running shoes.",
      status: 'Active',
      lastUpdated: new Date(),
      variants: [
        { size: '9', color: 'Grey', price: 1999, stock: 12 }
      ]
    }
  ];

  // UI state
  mode: 'list' | 'form' = 'list';
  editingId: number | null = null;

  // Filters
  searchTerm = '';
  categoryFilter = 'All';
  statusFilter: 'All' | 'Active' | 'Inactive' = 'All';

  // Reactive form
  productForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.productForm = this.buildForm();
  }

  // Build reactive form with variants as FormArray
  private buildForm(): FormGroup {
    return this.fb.group({
      image: [''],
      name: ['', [Validators.required, Validators.maxLength(120)]],
      category: ['', [Validators.required, Validators.maxLength(60)]],
      description: [''], // Replace with Quill editor once ngx-quill is installed
      status: [true], // true => Active, false => Inactive
      variants: this.fb.array<FormGroup>([])
    });
  }

  get variantsFA(): FormArray<FormGroup> {
    return this.productForm.get('variants') as FormArray<FormGroup>;
  }

  private createVariantRow(v?: Variant): FormGroup {
    return this.fb.group({
      size: [v?.size || '', Validators.required],
      color: [v?.color || '', Validators.required],
      price: [v?.price ?? null, [Validators.required, Validators.min(0)]],
      stock: [v?.stock ?? null, [Validators.required, Validators.min(0)]]
    });
  }

  // Derived options
  get categories(): string[] {
    const set = new Set(this.products.map(p => p.category));
    return ['All', ...Array.from(set)];
  }

  // Filtered list
  get filteredProducts(): Product[] {
    return this.products
      .filter(p => !this.searchTerm || p.name.toLowerCase().includes(this.searchTerm.toLowerCase()))
      .filter(p => this.categoryFilter === 'All' || p.category === this.categoryFilter)
      .filter(p => this.statusFilter === 'All' || p.status === this.statusFilter)
      .sort((a, b) => b.lastUpdated.getTime() - a.lastUpdated.getTime());
  }

  // List actions
  onAddProduct(): void {
    this.mode = 'form';
    this.editingId = null;
    this.productForm.reset({ image: '', name: '', category: '', description: '', status: true });
    this.variantsFA.clear();
    // Start with one empty variant row
    this.variantsFA.push(this.createVariantRow());
  }

  onEditProduct(p: Product): void {
    this.mode = 'form';
    this.editingId = p.id;
    this.productForm.reset({
      image: p.image,
      name: p.name,
      category: p.category,
      description: p.description,
      status: p.status === 'Active'
    });
    this.variantsFA.clear();
    p.variants.forEach(v => this.variantsFA.push(this.createVariantRow(v)));
  }

  onDeleteProduct(id: number): void {
    this.products = this.products.filter(p => p.id !== id);
  }

  // Form actions
  onAddVariant(): void {
    this.variantsFA.push(this.createVariantRow());
  }

  onRemoveVariant(index: number): void {
    this.variantsFA.removeAt(index);
  }

  onCancel(): void {
    this.mode = 'list';
  }

  onSave(): void {
    if (this.productForm.invalid || this.variantsFA.length === 0) {
      this.productForm.markAllAsTouched();
      return;
    }

    const formVal = this.productForm.value as any;
    const newProduct: Product = {
      id: this.editingId ?? this.nextId(),
      name: formVal.name,
      category: formVal.category,
      image: formVal.image || '',
      description: formVal.description || '',
      status: formVal.status ? 'Active' : 'Inactive',
      lastUpdated: new Date(),
      variants: (formVal.variants || []) as Variant[]
    };

    if (this.editingId) {
      const idx = this.products.findIndex(p => p.id === this.editingId);
      if (idx >= 0) this.products[idx] = newProduct;
    } else {
      this.products.unshift(newProduct);
    }

    this.mode = 'list';
    this.editingId = null;
  }

  private nextId(): number {
    return this.products.length ? Math.max(...this.products.map(p => p.id)) + 1 : 1;
  }

  // Image upload: store as data URL in form for preview/persistence in memory
  onImageSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;
    const file = input.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      this.productForm.patchValue({ image: reader.result as string });
    };
    reader.readAsDataURL(file);
  }
}

// Types
export interface Variant {
  size: string;
  color: string;
  price: number;
  stock: number;
}

export interface Product {
  id: number;
  name: string;
  category: string;
  image: string;
  description: string;
  status: 'Active' | 'Inactive';
  lastUpdated: Date;
  variants: Variant[];
}
